package com.liveaction.selenium.datamodel;


	public enum ReportTypeData {

		Flow("Flow"), QOS("QOS"),
		StaffPicks("Staff Picks"),
		IPsandPorts("IPs and Ports"), 
		InterfaceBandwidth("Interface Bandwidth"), 
		 
		
		//address section values
		Address("Address"),
		AddressPair("Address Pair"), 
		BidirectionalSource("Bidirectional Source/Destination Pair"), 
		DestinationAddress("Destination Address"),
		DestinationAddressPopularity("Destination Address Popularity"),
		DestinationSiteTraffic("Destination Site Traffic"),		
		SiteTraffic("Site Traffic"),
		SourceAddress("Source Address"),
		SourceAddressPopularity("Source Address Popularity"),
		SourceSiteTraffic("Source Site Traffic"),
		SourceORDestinationAddress("Source or Destination Address"),
		TopConversations("Top Conversations"),
		
		//AnyConnect sections values
		AnyConnect("AnyConnect"),
		AnyConnectApplicationVersions("AnyConnect Application Versions"),
		AnyConnectApplications("AnyConnect Applications"),
		AnyConnectUserDevices("AnyConnect User Devices"),
		AnyConnectUserSummary("AnyConnect User Summary"),
		AnyConnectUsers("AnyConnect Users"),
		
		//Applications section values
		Applications("Applications"), Application("Application"), ApplicationGroup("Application Group"),
		BusinessRelevance("Business Relevance"), Protocol("Protocol"), 	ProtocolPort("Protocol Port"),
		TrafficClass("Traffic Class"),
		
		//Applications (AVC) section values
		ApplicationsAVC("Applications (AVC)"),
		AVCApplication("AVC Application"), HTTPHost("HTTP Host"), PolicyClassification("Policy Classification"),
		TopApplicationsPerformance("Top Applications Performance"), 
		TopPolicyApplicationsPerformance("Top Policy Applications Performance"), 
		TopPolicyPerformance("Top Policy Performance"),
		
		Firewall("Firewall"),
		ACLPair("ACL Pair"), NetworkSecurityDeniedEvents("Network Security Denied Events"),
		
		Medianet("Medianet"),
		JitterLoss("Jitter/Loss"),
		RoundTripTime("Round-Trip Time"),
		
		Miscellaneous("Miscellaneous"),
		DestinationCountry("Destination Country"),
		DeviceFlowCount("Device Flow Count"),
		SourceCountry("Source Country"), UserFilter("User Filter"), 
		
		Network("Network"),
		
		PfR("PfR"),
		
		QoS("QoS"),
		ApplicationDSCPAudit("Application DSCP Audit"),
		DSCP("DSCP"),
		TypeOfService("Type of Service"),
		UserFilterDSCPAudit("User Filter DSCP Audit"),
		
		Wireless("Wireless"),
		WirelessAccessPoint("Wireless Access Point"),
		WirelessAccessPointApplication("Wireless Access Point Application"),
		WirelessAccessPointUniqueClients("Wireless Access Point Unique Clients"),
		WirelessClient("Wireless Client"),
		WirelessSSID("Wireless SSID"),
		WirelessSSIDApplication("Wireless SSID Application"),
		WirelessSSIDDSCP("Wireless SSID DSCP"),
		WirelessSSIDUniqueClients("Wireless SSID Unique Clients"),
		;

		private String value;

		private ReportTypeData(String value) {
			this.value = value;
		}
		
		public String toString() {
			return value;
		}
	}



