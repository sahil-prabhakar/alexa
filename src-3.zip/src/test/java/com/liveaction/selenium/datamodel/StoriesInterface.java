package com.liveaction.selenium.datamodel;

public enum StoriesInterface {

	TopInterfaceBandwidthChanges("Top Interface Bandwidth Changes")	,
	TopCPUUsageChanges("Top CPU Usage Changes"),
	TopMemoryUsageChanges("Top Memory Usage Changes"),
	
	;
	
	private String value;

	private StoriesInterface(String value) {
		this.value = value;
	}
	
	public String toString() {
		return value;
	}
}
