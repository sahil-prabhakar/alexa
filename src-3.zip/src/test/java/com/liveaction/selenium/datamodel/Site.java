package com.liveaction.selenium.datamodel;


 public enum Site  {
	 
	 
	    SiteA("All Sites (All Devices)"),
		SiteB("BOS"), 
	    SiteC("CHI") ,
		SiteD("Chicago"),
		SiteE("DataCenterCA"),
		SiteF("DataCenterNE"),;
	 
		private String value;

		private Site(String value) {
			this.value = value;
		}
		
		public String toString() {
			return value;
		}

}
