package com.liveaction.selenium.datamodel;

public enum  TimeRangeData {
	
	LastFifteenMinutes("Last Fifteen Minutes"),
	LastHour("Last Hour"),
	LastDay("Last Day"),
	LastWeek("Last Week"),
	LastThirtyDays("Last Thirty Days"),
	Custom("Custom");
	
	private String value;

	private TimeRangeData(String value) {
		this.value = value;
	}
	
	public String toString() {
		return value;
	}
}
