package com.liveaction.selenium.datamodel;

public enum Stories {

	TopInterfaceBandwidthChanges("Top Interface Bandwidth Changes")	,
	TopCPUUsageChanges("Top CPU Usage Changes"),
	TopMemoryUsageChanges("Top Memory Usage Changes"),
	
	//title
	DevicesInterfacesSummary("Devices/Interfaces Summary"),
	Interfaces("Interfaces"),
	Devices("Devices"),
	
	Device("Device"),
	DeviceSerial("Device Serial"),
	IPAddress("IP Address"),
	Site("Site"),
	Node("Node"),
	Tags("Tags"),
	Group("Group"),
	Description("Description"),
	
	InterfaceName("Interface Name"),
	InIF("In IF"),
	Label("Label"),
	Capacity("Capacity"),
	Type("Type"),
	Speed("Speed"),
	WAN("WAN"),
	InterfaceDescription("Interface Description");
	
	private String value;

	private Stories(String value) {
		this.value = value;
	}
	
	public String toString() {
		return value;
	}
}
