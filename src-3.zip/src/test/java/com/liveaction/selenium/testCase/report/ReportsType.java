package com.liveaction.selenium.testCase.report;

import static com.liveaction.selenium.datamodel.ReportTypeData.Address;
import static com.liveaction.selenium.datamodel.ReportTypeData.AddressPair;
import static com.liveaction.selenium.datamodel.ReportTypeData.*;
import static com.liveaction.selenium.datamodel.TimeRangeData.*;
import static org.testng.Assert.assertTrue;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.google.inject.Inject;
import com.liveaction.selenium.framework.BaseTest;
import com.liveaction.selenium.pageObject.LoginPage;
import com.liveaction.selenium.pageObject.NavBarPageObject;
import com.liveaction.selenium.pageObject.ReportPage;
import com.liveaction.selenium.testCase.LoginTest;


public class ReportsType extends BaseTest {

	private static final Logger logger = LoggerFactory.getLogger(LoginTest.class);

    @Inject private LoginPage loginPage;    
    @Inject private NavBarPageObject navBar; 
    @Inject private ReportPage reportPage;
    
 
    
    @Test(description = "verify report flow", dataProvider = "ReportsData")
    public void testReportFlow(List<String> reportType, String timeRange) throws InterruptedException {
    	navBar.clickOnReports(); 
    	
    	reportLog("click on report drop down field");
    	reportPage.clickReportDropDown();
    	
    	//select report type
    	reportLog("Slected report type "+AddressPair.toString()+" form "+Flow.toString());    	
    	//List<String> reports = new ArrayList<String>(Arrays.asList(Flow.toString(), Address.toString(), AddressPair.toString() ));
    	reportPage.selectReport(reportType); 
    	
    	//select time range
    	reportLog("select "+LastFifteenMinutes.toString()+ " from time range");
    	reportPage.clickTimeRangeDropDown();
    	reportPage.selectTimeRange(timeRange);
    	
    	//select devices
    	reportLog("select channel");
    	reportPage.selectDevice();
    	
    	reportLog("click on execute button");
    	reportPage.clickExecuteButton();
    	captureScreenshot("Report");
      
    }
    
       
    @DataProvider(name = "ReportsData")
	public static Object[][] listDevices() {

		Object obj[][] = new Object[10][2];

		return new Object[][] { { new ArrayList<String>(Arrays.asList(Flow.toString(), Address.toString(), AddressPair.toString() )), LastFifteenMinutes.toString()}, 
			{ new ArrayList<String>(Arrays.asList(Flow.toString(), Address.toString(), BidirectionalSource.toString() )), LastHour.toString() } ,
			{ new ArrayList<String>(Arrays.asList(Flow.toString(), Address.toString(), DestinationAddress.toString())), LastHour.toString() } ,
			{ new ArrayList<String>(Arrays.asList(Flow.toString(), AnyConnect.toString(), AnyConnectApplicationVersions.toString() )), LastDay.toString() } ,
			{ new ArrayList<String>(Arrays.asList(Flow.toString(), AnyConnect.toString(), AnyConnectApplications.toString() )), LastWeek.toString()} };
	}


}
