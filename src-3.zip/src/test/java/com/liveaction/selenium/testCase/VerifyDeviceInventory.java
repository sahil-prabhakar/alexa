package com.liveaction.selenium.testCase;

import static com.liveaction.selenium.datamodel.ReportTypeData.Address;
import static com.liveaction.selenium.datamodel.ReportTypeData.AddressPair;
import static com.liveaction.selenium.datamodel.ReportTypeData.AnyConnect;
import static com.liveaction.selenium.datamodel.ReportTypeData.AnyConnectApplicationVersions;
import static com.liveaction.selenium.datamodel.ReportTypeData.AnyConnectApplications;
import static com.liveaction.selenium.datamodel.ReportTypeData.BidirectionalSource;
import static com.liveaction.selenium.datamodel.ReportTypeData.DestinationAddress;
import static com.liveaction.selenium.datamodel.ReportTypeData.Flow;
import static com.liveaction.selenium.datamodel.Stories.Capacity;
import static com.liveaction.selenium.datamodel.Stories.Description;
import static com.liveaction.selenium.datamodel.Stories.Device;
import static com.liveaction.selenium.datamodel.Stories.DeviceSerial;
import static com.liveaction.selenium.datamodel.Stories.Devices;
import static com.liveaction.selenium.datamodel.Stories.DevicesInterfacesSummary;
import static com.liveaction.selenium.datamodel.Stories.Group;
import static com.liveaction.selenium.datamodel.Stories.IPAddress;
import static com.liveaction.selenium.datamodel.Stories.InIF;
import static com.liveaction.selenium.datamodel.Stories.InterfaceDescription;
import static com.liveaction.selenium.datamodel.Stories.InterfaceName;
import static com.liveaction.selenium.datamodel.Stories.Interfaces;
import static com.liveaction.selenium.datamodel.Stories.Label;
import static com.liveaction.selenium.datamodel.Stories.Node;
import static com.liveaction.selenium.datamodel.Stories.Site;
import static com.liveaction.selenium.datamodel.Stories.Speed;
import static com.liveaction.selenium.datamodel.Stories.Tags;
import static com.liveaction.selenium.datamodel.Stories.Type;
import static com.liveaction.selenium.datamodel.Stories.WAN;
import static com.liveaction.selenium.datamodel.TimeRangeData.LastDay;
import static com.liveaction.selenium.datamodel.TimeRangeData.LastFifteenMinutes;
import static com.liveaction.selenium.datamodel.TimeRangeData.LastHour;
import static com.liveaction.selenium.datamodel.TimeRangeData.LastWeek;

import static com.liveaction.selenium.datamodel.Site.SiteE;
import static com.liveaction.selenium.datamodel.Site.SiteD;
import static com.liveaction.selenium.datamodel.Site.SiteC;
import static com.liveaction.selenium.datamodel.Site.SiteB;
import static com.liveaction.selenium.datamodel.Site.SiteA;
import static org.testng.Assert.assertTrue;
import static org.testng.Assert.assertEquals;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.openqa.selenium.WebElement;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.google.inject.Inject;
import com.liveaction.selenium.framework.BaseTest;
import com.liveaction.selenium.framework.CSVReader;
import com.liveaction.selenium.pageObject.NavBarPageObject;
import com.liveaction.selenium.pageObject.stories.DeviceInventoryPage;

public class VerifyDeviceInventory extends BaseTest {

	@Inject
	private NavBarPageObject navBar;
	@Inject
	private DeviceInventoryPage deviceInventoryPage;

	//@Test(description = "author:")
	public void testVerifyInterfaceCapacityPage() throws InterruptedException {

		// Click on device Inventory Page
		navBar.clickOnstoriesLink();
		navBar.clickOndeviceInventoryLink();

		assertTrue(deviceInventoryPage.getHeader().contains(DevicesInterfacesSummary.toString()));

		// Select the site from Site DropDown
		deviceInventoryPage.selectDevice("BRANCH1");
		assertTrue(deviceInventoryPage.isSelected("BRANCH1"));
	}

	//@Test(description = "author:")
	public void testVerifySidePanelsLinksInDeviceInventory() throws InterruptedException {

		// Click on device Inventory Page
		navBar.clickOnstoriesLink();
		navBar.clickOndeviceInventoryLink();
		assertTrue(deviceInventoryPage.getHeader().contains(DevicesInterfacesSummary.toString()));

		// Select the Devices link
		deviceInventoryPage.clickDevicesLink();
		deviceInventoryPage.isHeaderTitle(Devices.toString());

		// Select the Interfaces link
		deviceInventoryPage.clickInterfacesSideLink();
		deviceInventoryPage.isHeaderTitle(Interfaces.toString());

	}

	//@Test(description = "author:")
	public void testVerifyDevicesInterfaceSummaryTable() throws InterruptedException {
		// Click on device Inventory Page
		navBar.clickOnstoriesLink();
		navBar.clickOndeviceInventoryLink();

		// Verify the Devices/Interfaces header
		assertTrue(deviceInventoryPage.getHeader().contains(DevicesInterfacesSummary.toString()));

		// Verify data is present in Table
		assertTrue(deviceInventoryPage.isDeviceTableContainsData());
		List<String> deviceHeaderTable = new ArrayList<String>(
				Arrays.asList(Device.toString(), DeviceSerial.toString(), IPAddress.toString(), Site.toString(),
						Node.toString(), Tags.toString(), Group.toString(), Description.toString()));
		deviceInventoryPage.verifyDevicesHeader(deviceHeaderTable);

		// Verify the header is "Interfaces"
		deviceInventoryPage.isHeaderTitle(Interfaces.toString());

		// Verify data is present in Table
		assertTrue(deviceInventoryPage.isInterfaceTableContainsData());
		List<String> interfaceHeaderTable = new ArrayList<String>(
				Arrays.asList(InterfaceName.toString(), Device.toString(), IPAddress.toString(), InIF.toString(),
						Tags.toString(), Site.toString(), Label.toString(), Capacity.toString(), Type.toString(),
						Speed.toString(), WAN.toString(), InterfaceDescription.toString()));
		deviceInventoryPage.verifyInterfaceHeader(interfaceHeaderTable);

	}

	//@Test(description = "author:")
	public void testVerifyDevicesInterfaceDataContainsLink() throws InterruptedException {
		// Click on device Inventory Page
		navBar.clickOnstoriesLink();
		navBar.clickOndeviceInventoryLink();

		// Verify the Devices/Interfaces header
		assertTrue(deviceInventoryPage.getHeader().contains(DevicesInterfacesSummary.toString()));

		// verify devices data table's device column contains link
		deviceInventoryPage.verifyDeviceColumnContainsLink();

		// verify interface data table's device and interface name column
		// contains link
		deviceInventoryPage.verifyInterfaceNameContainsLink();
	}

	//@Test(description = "author:")
	public void testVerifySearchFunctionaity() throws InterruptedException {
		// Click on device Inventory Page
		navBar.clickOnstoriesLink();
		navBar.clickOndeviceInventoryLink();

		// verify search functionality
		deviceInventoryPage.searchInterface("SNMPSIM-172-18-13-8");
	}
		
	//@Test(description = "author:")
	public void testDeviceAndInterfaceTimeRange() throws InterruptedException {
		// Click on device Inventory Page
		navBar.clickOnstoriesLink();
		navBar.clickOndeviceInventoryLink();
		assertTrue(deviceInventoryPage.getHeader().contains(DevicesInterfacesSummary.toString()));

		// verify time range
		deviceInventoryPage.verifyDeviceTime();
		deviceInventoryPage.verifyInterfaceTime();		
	}
	
	//@Test(description = "author:")
	public void testExportCSVDeviceData() throws InterruptedException {
		// Click on device Inventory Page
		navBar.clickOnstoriesLink();
		//navBar.clickOndeviceInventoryLink();
		assertTrue(deviceInventoryPage.getHeader().contains(DevicesInterfacesSummary.toString()));

		// Export csv data
		deviceInventoryPage.exportDeviceData();
		Thread.sleep(4000);
		List<String> deviceHeaderTable = new ArrayList<String>(
				Arrays.asList(Device.toString(), DeviceSerial.toString(), IPAddress.toString(), Site.toString(),
						Node.toString(), Tags.toString(), Group.toString(), Description.toString()));
		
		deviceInventoryPage.verifyCSVHeader(deviceHeaderTable, CSVReader.getHeader("Devices"));
	}
	
	//@Test(description = "author:")
	public void testExportCSVInterfaceData() throws InterruptedException {
		// Click on device Inventory Page
		navBar.clickOnstoriesLink();
		navBar.clickOndeviceInventoryLink();
		assertTrue(deviceInventoryPage.getHeader().contains(DevicesInterfacesSummary.toString()));

		// Export csv data
		deviceInventoryPage.clickInterfacesSideLink();
		Thread.sleep(2000);
		deviceInventoryPage.exportInterfaceData();
		Thread.sleep(2000);
		
		//verify csv data headers
		List<String> interfaceHeaderTable = new ArrayList<String>(
				Arrays.asList(InterfaceName.toString(), Device.toString(), IPAddress.toString(), InIF.toString(),
						Tags.toString(), Site.toString(), Label.toString(), Capacity.toString(), Type.toString(),
						Speed.toString(), WAN.toString(), InterfaceDescription.toString()));
		deviceInventoryPage.verifyCSVHeader(interfaceHeaderTable, CSVReader.getHeader("Interfaces"));
		
	}
	
	
	//@Test(groups = "Sahil",description= " ")
	public void clickonDevice() throws InterruptedException
	{


		//click on the devices
		navBar.clickOnstoriesLink();
		navBar.clickOndeviceInventoryLink();
		assertEquals(deviceInventoryPage.getCSVLinkCount(),2);
	   WebElement w= deviceInventoryPage.getCellLink(1, 1);
	   WebElement k=deviceInventoryPage.getCellLink(1,2);
	  String deviceInfo=k.getText();
		  
	   String s=w.getText();
	   //String device information and use equals
	   s=s.replace("0/0", "");
	   System.out.println("String is "+s);
	   
	   w.click();
	  String url= deviceInventoryPage.getPageUrl();
	  System.out.println("String is "+url);
	  assertTrue(url.contains(s),"Verify URL contains Interface Details");
	 
	}
	//@Test(groups = "reports", testName = "Test Reports ", description = "Verify Interface details for a Device")
	 
	public void test_ALM82062_VerifyInterfaceDetails(List<String> deviceSelection,String text){
	  
	  reportLog("Step 1- Navigate to Interface Capacity Page");
	  navBar.clickOnstoriesLink();
	  reportLog("Click on Interface Capacity Page");
	  navBar.clickOnInterfaceCapacity();
	 
	  String devicevalue=deviceSelection.get(0);
	 // DeviceInventoryPage.selectDevice("devicevalue");
	  
	
	  
	 }
	
	  @DataProvider(name = "SiteData")
		public static Object[][] listDevices() {

			Object obj[] = new Object[10][2];

			return new Object[][] {
				{ new ArrayList<String>(Arrays.asList(SiteA.toString(),"Devices/Interfaces Summary"))},
					{new ArrayList<String>(Arrays.asList(SiteB.toString(),"Devices/Interfaces Summary"))},
			         {new ArrayList<String>(Arrays.asList(SiteC.toString(),"Devices/Interfaces Summary"))},
			         {new ArrayList<String>(Arrays.asList(SiteD.toString(),"Devices/Interfaces Summary"))}};
			
		              }
	
	@Test(description= "Click on the interface drop down value in the interface device page ",dataProvider="SiteData")
	public void verifyReportForSites(List<String> deviceSelection) throws InterruptedException
	{
		//Verify the headers and the links
		reportLog("Click on the Stories Link");
		navBar.clickOnstoriesLink();
	    reportLog("Click on Device Inventory Link");
		navBar.clickOndeviceInventoryLink();

		 reportLog("Click on Each of the Sites in the drop down"+SiteA.toString());
		 String device=deviceSelection.get(0);
		 System.out.print("Device is"+device);
		
		reportLog("Select the count of the table");
	    assertTrue(deviceInventoryPage.isDeviceTableContainsData());
	    
	    reportLog("Verify that there is no error message");
		 
	}
	
	
	//@Test(description= "Verify the Export is working",dataProvider="SiteData")
	public void interfaceDetailsduration(List<String> deviceSelection ,String text) throws InterruptedException
	{
		//Verify the headers and the links
		
		
		
		//Verify the different reports can be exported
		
		
		//Verify the start and end time 
		
	
		//verify the device details table--Cpu and Memory Usage table
		
		//verify the reports are present or there is message
		
		
		//verify there is no "Error Retrieving data message"
		
	 
	}
	@Test
	public void getLinks()
	{
	 
	}

		
	

}
