package com.liveaction.selenium.testCase.homepage;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.google.inject.Inject;
import com.liveaction.selenium.framework.BaseTest;
import com.liveaction.selenium.framework.SikuliSupport;
import com.liveaction.selenium.pageObject.LoginPage;
import com.liveaction.selenium.testCase.LoginTest;

public class SikuliChartVerification extends BaseTest {
	private static final Logger logger = LoggerFactory.getLogger(LoginTest.class);

	@Inject
	private LoginPage loginPage;
	
	@Test(description = "author:")
	public void testVerificationHomeGraphs() throws InterruptedException {
		SikuliSupport.waitForImage("Device.png");
		Assert.assertTrue(SikuliSupport.isImagePresent("Device.png"));
		Assert.assertTrue(SikuliSupport.isImagePresent("Sites.png"));
		Assert.assertTrue(SikuliSupport.isImagePresent("Graph.png"));
	}

}
