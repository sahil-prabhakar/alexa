package com.liveaction.selenium.testCase;

import com.google.inject.Inject;
import com.liveaction.selenium.framework.BaseTest;
import com.liveaction.selenium.pageObject.LoginPage;
import com.liveaction.selenium.pageObject.NavBarPageObject;
import com.liveaction.selenium.pageObject.settings.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.annotations.Test;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertTrue;

/**
 * @author hanson
 */
public class SettingsTest extends BaseTest{
    private static final Logger logger = LoggerFactory.getLogger(SettingsTest.class);

    @Inject private LoginPage loginPage;
    @Inject private NavBarPageObject navBar;
    @Inject private SettingsSideBarPageObject settingsBar;
    @Inject private ConfigureTestsPage configureTestsPage;
    @Inject private ConfigureAgentsPage configureAgentsPage;
    @Inject private ConfigureThresholdsPage configureThresholdsPage;
    @Inject private ChangePasswordPage changePasswordPage;
    @Inject private ConfigureApiPage configureApiPage;
    @Inject private DatabasePage databasePage;
    @Inject private AboutPage aboutPage;

    @Test(description = "author:rhanson")
    public void configureTestsAndAddTestAreReachable() {
        logger.info("Checking: settings -> configure tests -> add test");
        loginPage.login();
        navBar.clickSettings();
        assertEquals(configureTestsPage.getSettingTitle(), "Configure Tests");
        configureTestsPage.clickAddTestButton();
        assertTrue(configureTestsPage.isCreateNewTestTitlePresent());
    }

    @Test(description = "author:rhanson" , enabled=false)
    public void configureAgentsIsReachable() {
        logger.info("Checking: settings -> configure agents");
        loginPage.login();
        navBar.clickSettings();
        settingsBar.clickConfigureAgents();
        assertEquals(configureAgentsPage.getSettingTitle(), "Configure Agents");
        assertTrue(configureAgentsPage.isSearchBarPresent());
    }

    @Test(description = "author:rhanson", enabled=false)
    public void configureThresholdsAndAddAreReachable() {
        logger.info("Checking: settings -> configure thresholds -> create template");
        loginPage.login();
        navBar.clickSettings();
        settingsBar.clickConfigureThresholds();
        assertEquals(configureThresholdsPage.getSettingTitle(), "Configure Thresholds");
        configureThresholdsPage.clickCreateTemplateButton();
        assertTrue(configureThresholdsPage.isConfigureThresholdTemplateFormPresent());
    }

    @Test(description = "author:rhanson")
    public void changePasswordIsReachable() throws InterruptedException {
        logger.info("Checking: settings -> change password");
        loginPage.login();
        navBar.clickSettings();
        settingsBar.clickChangePassword();
        assertEquals(changePasswordPage.getSettingTitle(), "Change Password");
        assertTrue(changePasswordPage.isChangePasswordFormPresent());
    }

    @Test(description = "author:rhanson")
    public void configureApiIsReachable() throws InterruptedException {
        logger.info("Checking: settings -> configure api");
        loginPage.login();
        navBar.clickSettings();
        settingsBar.clickConfigureApi();
        assertEquals(configureApiPage.getSettingTitle(), "Configure API Key");
        assertTrue(configureApiPage.isApiKeyFormPresent());
    }

    @Test(description = "author:rhanson")
    public void aboutSettingIsReachable() throws InterruptedException {
        logger.info("Checking: settings -> about");
        loginPage.login();
        navBar.clickSettings();
        settingsBar.clickAbout();
        assertEquals(aboutPage.getSettingTitle(), "About");
    }

    @Test(description = "author:rhanson")
    public void databaseSettingIsReachable() {
        logger.info("Checking: settings -> database");
        loginPage.login();
        navBar.clickSettings();
        settingsBar.clickDatabase();
        assertEquals(databasePage.getSettingTitle(), "Database");
        assertTrue(databasePage.isUsageTablePresent());
    }
}
