package com.liveaction.selenium.testCase.report;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.testng.annotations.Test;

import com.google.inject.Inject;
import com.liveaction.selenium.framework.BaseTest;
import com.liveaction.selenium.pageObject.NavBarPageObject;
import com.liveaction.selenium.pageObject.ReportPage;
import com.liveaction.selenium.testCase.LoginTest;
import static com.liveaction.selenium.datamodel.ReportTypeData.*;
import static com.liveaction.selenium.datamodel.TimeRangeData.*;

public class ReportType extends BaseTest {
    private static final Logger logger = LoggerFactory.getLogger(LoginTest.class);

   
    @Inject private NavBarPageObject navBar; 
    @Inject private ReportPage reportPage;
 
  
    
    @Test(description = "selecting reports:")
    public void testReportFlow() throws InterruptedException {
    	navBar.clickOnReports();
    	reportLog("click on report drop down field");
    	reportPage.clickReportDropDown();
    	
    	//select report type
    	reportLog("Selected report type "+AddressPair.toString()+" form "+Flow.toString());    	
    	List<String> reports = new ArrayList<String>(Arrays.asList(Flow.toString(), Address.toString(), AddressPair.toString() ));
    	reportPage.selectReport(reports); 
    	
    	//select time range
    	reportLog("select "+LastFifteenMinutes.toString()+ " from time range");
    	reportPage.clickTimeRangeDropDown();
    	reportPage.selectTimeRange(LastFifteenMinutes.toString());
    	
    	//select devices
    	reportLog("select channel");
    	reportPage.selectDevice();
    	
    	reportLog("click on execute button");
    	reportPage.clickExecuteButton();
    	captureScreenshot("Report");
      //  navBar.logout();
      //  assertTrue(loginPage.isloginWithLiveActionFieldPresent());
    }
    
    
    @Test(description = "selecting reports:")
    public void testExport() throws InterruptedException {
    	navBar.clickOnReports();
    	reportLog("click on export button");
    	
   
    	captureScreenshot("Report button");
      //  navBar.logout();
      //  assertTrue(loginPage.isloginWithLiveActionFieldPresent());
    }
    
    
    
 
    }
    
    


