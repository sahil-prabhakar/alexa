package com.liveaction.selenium.testCase;

import static org.testng.Assert.assertTrue;

import org.apache.commons.io.FilenameUtils;
import org.testng.annotations.Test;

import com.google.inject.Inject;
import com.liveaction.selenium.framework.BaseTest;
import com.liveaction.selenium.framework.Utils;
import com.liveaction.selenium.pageObject.InventoryDetailsPage;
import com.liveaction.selenium.pageObject.NavBarPageObject;
import com.liveaction.selenium.pageObject.InterfaceCapacityPage;

public class VerifyInterfaceDetailPage extends BaseTest{
   
    @Inject private NavBarPageObject navBar;
    @Inject private InterfaceCapacityPage interfaceCapacityPage;
    @Inject private InventoryDetailsPage inventoryDetailsPage;
    
	@Test(groups = "Interface Capacity", testName = "test_ALM82062_VerifInterfaceDetails", description = "Verify Interface details for a Device")
	public void test_ALM82062_VerifyInterfaceDetails(){
		
		reportLog("Step 1- Navigate to Interface Capacity Page");
		navBar.clickOnstoriesLink();
		navBar.clickOnInterfaceCapacity();
		
		reportLog("Step 2- Navigate to Interface Bandwidth Changes section.");
		interfaceCapacityPage.navigateToInterCapacitySection("Top Interface Bandwidth Changes");
		
		reportLog("Step 3- Navigate to Interface Bandwidth Detail Page.");
		String deviceInformation = interfaceCapacityPage.getInterBandWidthChangesTblCell(1, 1).getText();
		String interfaceName = interfaceCapacityPage.getInterBandWidthChangesTblCell(1, 2).getText();
		interfaceCapacityPage.navigateToInterfaceDetailsPage(1, 2);
		
		reportLog("Step 4- Verify Interface details page data");
		assertTrue(inventoryDetailsPage.getDeviceLabel().contains(deviceInformation), " Verify Device value on Interface detail page");
		assertTrue(inventoryDetailsPage.getInterfaceLabel().contains(interfaceName), " Verify Interface value on Interface detail page");
		
	}
	
	@Test(groups = "Interface Capacity", testName = "test_ALM82063_VerifyInterfaceBandwidthSection", description = "Verify Interface details bandwidth section")
	public void test_ALM82063_VerifyInterfaceBandwidthSection(){
		
		reportLog("Step 1- Navigate to Interface Capacity Page");
		navBar.clickOnstoriesLink();
		navBar.clickOnInterfaceCapacity();
		
		reportLog("Step 2- Navigate to Interface Bandwidth Changes section.");
		interfaceCapacityPage.navigateToInterCapacitySection("Top Interface Bandwidth Changes");
		
		reportLog("Step 3- Navigate to Interface Bandwidth Detail Page.");
		interfaceCapacityPage.navigateToInterfaceDetailsPage(1, 2);
		
		reportLog("Step 4- Move to Interface details bandwidth data section");
		inventoryDetailsPage.moveToInterfaceDetailsSection("Interface Bandwidth");
		
		reportLog("Step 5- Verify Interface details bandwidth data section");
		assertTrue(inventoryDetailsPage.verifyInterfaceBandWidthHeader(), "Verify Interface bandwith header");
		assertTrue(inventoryDetailsPage.verifyInterfaceBandWidthStartTimeLbl(), "Verify Interface bandwith start time label");
		assertTrue(inventoryDetailsPage.verifyInterfaceBandWidthEndTimeLbl(), "Verify Interface bandwith start time label");
		assertTrue(inventoryDetailsPage.verifyInterfaceBandWidthStartTimeValue()," Verify Interface bandwidth start time value");
		assertTrue(inventoryDetailsPage.verifyInterfaceBandWidthEndTimeValue()," Verify Interface bandwidth end time value");
	}
	
	
	@Test(groups = "NotTestedYet", testName = "test_ALM82062_VerifyFileExtension", description = "Verify download file extension")
	public void test_ALM82064_InterfaceDetails(){
		
		reportLog("Step 1- Navigate to Interface Capacity Page");
		navBar.clickOnstoriesLink();
		navBar.clickOnInterfaceCapacity();
		
		reportLog("Step 2- Download CSV file.");
		interfaceCapacityPage.downloadTopMemoryUsageChangesCSV();
		
		reportLog("Step 3- Verify Downloaded file is CSV file.");
		assertTrue(FilenameUtils.isExtension(Utils.getLatestFile().getName(), "csv"));		
		
	}
}
