package com.liveaction.selenium.testCase;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.annotations.Test;
import com.google.inject.Inject;
import com.liveaction.selenium.framework.MainBase;
import com.liveaction.selenium.pageObject.LDAPManagement;
import com.liveaction.selenium.pageObject.LoginPage;
import com.liveaction.selenium.pageObject.NavBarPageObject;
import com.liveaction.selenium.pageObject.SiteManagement;
import com.liveaction.selenium.pageObject.WMICManagement;
import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertTrue;

public class configurePage extends MainBase {
	private static final Logger logger = LoggerFactory.getLogger(configurePage.class);

    @Inject private LoginPage loginPage;    
    @Inject private NavBarPageObject navBar;
    @Inject private LDAPManagement ldapManagement;
    @Inject private SiteManagement siteManagement;
    @Inject private WMICManagement wmicManagement;

    //click on the links and verify the header on the sublinks
	  @Test(description = "Verify the  configure links:")
	  public void testConfigureLinks() throws InterruptedException
	  { 
		  loginPage.login();
		  navBar.clickOnConfigure();
		 
		  navBar.clickOnSiteManagement();
		
		  assertTrue(siteManagement.isTitleText("Site Management"));
		  navBar.clickOnConfigure();
		  navBar.clickOnLDAPManagement();
		  assertTrue( ldapManagement.isTitleText("LDAP Management"));
		//  navBar.clickOnWMICManagement();
		//  assertTrue(wmicManagement.isTitleText("WMIC Management"));
		  
	  
	/*  @Test(description = "Verify the configureOnSiteManagement:")
	  public void cickConfigureonSite() throws InterruptedException
	  {
		  navBar.clickOnConfigure();
		  assertTrue( interfaceCapacityPage.isTitleText("Top Interface Bandwidth Changes"));
	  }
	  
	  @Test(description = "Verify the configureOnSiteManagement:")
	  public void testConfigureonSite() throws InterruptedException
	  {
		  navBar.clickOnConfigure();
		  assertTrue( interfaceCapacityPage.isTitleText("Site Management"));
	  }
	  
	  @Test(description = "Verify the configureOnSiteManagement:")
	  public void testUpload() throws InterruptedException
	  {
		  navBar.clickOnConfigure();
		  configurePage.clickUpload();
		  assertTrue( uploadScreen.isTitleText("SITES LOCATION IMPORT"));
		  uploadScreen.clickOnBrowse();  
		  uploadScreen.cancel();
		  
	  }
	  
	  
	  @Test(description = "Verify the header information of table")
	  public void testUpload() throws InterruptedException
	  {
		  navBar.clickOnConfigure();
		  configurePage.clickUpload();
		  assertTrue( uploadScreen.isTitleText("Site Management"));
		  configurePage.verifyHeader();
		
	  }
	  */
	  
}
}

