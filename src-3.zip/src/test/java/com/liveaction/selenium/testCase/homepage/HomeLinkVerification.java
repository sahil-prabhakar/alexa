package com.liveaction.selenium.testCase.homepage;

import static org.testng.Assert.assertTrue;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.Assert;
import org.testng.annotations.Test;
import com.google.inject.Inject;
import com.liveaction.selenium.framework.BaseTest;
import com.liveaction.selenium.pageObject.HomePage;
import com.liveaction.selenium.pageObject.LoginPage;
import com.liveaction.selenium.pageObject.NavBarPageObject;
import com.liveaction.selenium.testCase.LoginTest;

public class HomeLinkVerification extends BaseTest {
    private static final Logger logger = LoggerFactory.getLogger(LoginTest.class);

    @Inject private LoginPage loginPage;    
    @Inject private NavBarPageObject navBar;    
    @Inject private HomePage homePage;
    
    @Test(description = "verify the login and logout is working in the home page")
    public void testVerificationHomePageLink() throws InterruptedException {
    	
        logger.info("Attempting login with valid credentials");
        loginPage.login();
        assertTrue(navBar.isLogoutButtonPresent());        
        navBar.clickOnHomePage();        
        assertTrue(homePage.isApplicationCharts());
        assertTrue(homePage.isSiteCharts());
        assertTrue(homePage.isDeviceCharts());
        
        navBar.logout();
        assertTrue(loginPage.isloginWithLiveActionFieldPresent());
    }
    
    @Test(description = "login with valid credentials")
    public void verifySiteDropDown(){    		
    	
    	 logger.info("Attempting login with valid credentials");
         assertTrue(navBar.isLogoutButtonPresent());        
         navBar.clickOnHomePage();   
         
         homePage.selectSiteFromDrop();
         assertTrue(homePage.isSiteListInDropDown());
         homePage.selectSite("BRANCH1");
         homePage.clear();
         
         navBar.logout();
         assertTrue(loginPage.isloginWithLiveActionFieldPresent());
    }
    
    
    @Test(description = "Test Default time select Drop down value and number of options")
    public void verifyTime(){ 
    	int size=5;
    	
    	 reportLog("Login to the page");
         loginPage.login();
         assertTrue(navBar.isLogoutButtonPresent());        
         
         //check the default value of the drop down
         Assert.assertEquals("Last Hour",homePage.selectDefaultTimeFromDropDown());
        
         reportLog("Count number is time drop down");
         Assert.assertEquals(size,homePage.timeSlectSize());
         
         navBar.logout();
         assertTrue(loginPage.isloginWithLiveActionFieldPresent());
    }
    
   
    
    @Test(description = "Click on the Sites link and verify page URL")
    public void verifySitePage()
    {  
        reportLog("Click on the Devices Link");
       
       assertTrue(homePage.selectSite("Devices"));
      // assertTrue(homePage.isHeaderTitle("Devices"));
        
        reportLog("Verify the page URL ");
        homePage.verifyURL("sites");
    	
    }
    
    
    @Test(description = "Verify the page does not give Error and Exports to CSV")
    public void verifySiteAndExport()
    { 
    	reportLog("Verify that certain text is not present");
    	homePage.isTextPresentOnPage("Error Retrieving Data");
    	
    	reportLog("Verify the export functionality to CSV");
    	homePage.devicesDownloadCSV();
        
        reportLog("Verify the CSV header");        
    	
    }    
    

}
