package com.liveaction.selenium.testCase;

import com.google.inject.Inject;
import com.liveaction.selenium.framework.BaseTest;
import com.liveaction.selenium.pageObject.LoginPage;
import com.liveaction.selenium.pageObject.NavBarPageObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.annotations.Test;




public class VerifyConfigureNav extends BaseTest{
	 private static final Logger logger = LoggerFactory.getLogger(VerifyConfigureNav.class);

	    @Inject private LoginPage loginPage;
	    @Inject private NavBarPageObject navBar;
	//    @Inject private DeviceInventoryPage deviceInvPage;
	
	  @Test(description = "author:rhanson", enabled=true)
	    public void configureThresholdsAndAddAreReachable() {
	      //  logger.info("Checking: settings -> configure thresholds -> create template");
	        loginPage.login();
	        navBar.clickOnstoriesLink();
	        navBar.clickOndeviceInventoryLink();
	       // assertEquals(deviceInvPage.getHeader(), "WAN Interface Capacity Summary");
	       // configureThresholdsPage.clickCreateTemplateButton();
	       // 	assertTrue(configureThresholdsPage.isConfigureThresholdTemplateFormPresent());
	    }

	  @Test(description = "author:rhanson", enabled=true)
	    public void configureThresholdsAndAddAreReachable1() {
	       logger.info("Checking: settings -> configure thresholds -> create template");
	       
	    }

}
