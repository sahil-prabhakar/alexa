package com.liveaction.selenium.testCase;

import static org.testng.Assert.assertTrue;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import static com.liveaction.selenium.datamodel.Stories.*;
import com.google.inject.Inject;
import com.liveaction.selenium.framework.BaseTest;
import com.liveaction.selenium.pageObject.NavBarPageObject;
import com.liveaction.selenium.pageObject.stories.InterfaceCapacityPage;

public class VerifyInterfaceCapacityPage extends BaseTest {
    	
    @Inject private NavBarPageObject navBar;
    @Inject private InterfaceCapacityPage interfaceCapacityPage;
    
    @Test(description = "This test case is clicking on the various  Interface capacity Links:")
    public void testVerifyInterfaceCapacityPage() throws InterruptedException {
    	 
    	//Navigate to the stories page
        navBar.clickOnstoriesLink();
        
        //Click on Interface Capacity Link
        navBar.clickOnInLink(); 
              
        //Click on Top Interface Bandwidth link
        reportLog("Click on Top Interface Bandwidth link");
        interfaceCapacityPage.clickLinks(TopInterfaceBandwidthChanges.toString());
        assertTrue( interfaceCapacityPage.isTitleText("Top Interface Bandwidth Changes"));
        
        //Click on Top CPU Usage Change Link
        reportLog("Click on Top CPU Usage Change Link");
        interfaceCapacityPage.clickLinks(TopCPUUsageChanges.toString());
        assertTrue( interfaceCapacityPage.isTitleText("Top CPU Usage Changes"));
        
        //Click on Top Memory Usage Change Link
        reportLog("Click on Top Memory Usage Change Link");
        interfaceCapacityPage.clickLinks(TopMemoryUsageChanges.toString());
        assertTrue( interfaceCapacityPage.isTitleText("Top Memory Usage Changes"));       
       
    }
    
    @Test(groups = "Interface Capacity", testName = "test_verifyInterfaceCapacityChart", description = "Verify Interface chart data")
    public void test_verifyInterfaceCapacityChart() throws InterruptedException{
    	
    	//Navigate to the stories page
    	reportLog("Navigate to the stories page");
        navBar.clickOnstoriesLink();
        
        //Click on Interface Capacity Link
        reportLog("Click on Interface Capacity Link");
        navBar.clickOnInLink(); 
        
        reportLog("verifying chart present");
		assertTrue(interfaceCapacityPage.verifyTopMemoryChart(), "Verify Top Memory Chart");
		assertTrue(interfaceCapacityPage.verifyTopCPUChart(), "Verify Top CPU Chart");
		assertTrue(interfaceCapacityPage.verifyTopInterfaceChart(), "Verify Top Interface Chart");	
		
    }
    
    @Test(groups = "Interface Capacity", testName = "test_verifyInterfaceCapacityTableData", description = "Verify Interface table data")
    public void test_verifyInterfaceCapacityTableData() throws InterruptedException{
    	
    	//Navigate to the stories page
    	reportLog("Navigate to the stories page");
        navBar.clickOnstoriesLink();
        
        //Click on Interface Capacity Link
        reportLog("Click on Interface Capacity Link");
        navBar.clickOnInLink(); 
       
		reportLog("verifying data table present");		
		interfaceCapacityPage.verifyTopInterfaceTableData();
		interfaceCapacityPage.verifyTopCPUTableData();
		interfaceCapacityPage.verifyTopMemoryTableData();
	}
        
    @Test(groups = "Interface Capacity", testName = "test_verifyInterfaceCapacityChartExportFunctionality", description = "Verify Interface chart export functionality")
    public void test_verifyInterfaceCapacityChartExportFunctionality() throws InterruptedException{
    	
    	//Navigate to the stories page
    	reportLog("Navigate to the stories page");
        navBar.clickOnstoriesLink();
        
        //Click on Interface Capacity Link
        reportLog("Click on Interface Capacity Link");
        navBar.clickOnInLink(); 
       		
		reportLog("export and verify png chart graph");
		interfaceCapacityPage.exportAndVerifyPngGraph();
	 }
    
    @Test(groups = "Interface Capacity", testName = "test_verifyInterfaceCapacityExportCSVFunctionality", description = "Verify Interface table data export functionality")
    public void test_verifyInterfaceCapacityExportCSVFunctionality() throws InterruptedException{
    	
    	//Navigate to the stories page
    	reportLog("Navigate to the stories page");
        navBar.clickOnstoriesLink();
        
        //Click on Interface Capacity Link
        reportLog("Click on Interface Capacity Link");
        navBar.clickOnInLink(); 
    		
		reportLog("export and verify excel data of chart graph");
		interfaceCapacityPage.exportAndVerifyCSVData();
		
		reportLog("export and verify excel data of table");
		interfaceCapacityPage.exportAndVerifyTableCSVData();
    }
        
    @Test(groups = "Interface Capacity", testName = "test_verifyInterfaceCapacityTablesHeaser", description = "Verify Interface table headers name")
    public void test_verifyInterfaceCapacityTablesHeader() throws InterruptedException{
    	
    	//Navigate to the stories page
    	reportLog("Navigate to the stories page");
        navBar.clickOnstoriesLink();
        
        //Click on Interface Capacity Link
        reportLog("Click on Interface Capacity Link");
        navBar.clickOnInLink(); 
        
        reportLog("verifying chart present");
		List<String> headersValue = new ArrayList<String>(Arrays.asList("Device", "Interface Name" , "Direction" , "Capacity" , "Percentile Bandwidth",
				"Percentile Utilizatio", "Percent Changed"));
		List<String> headersValueOfCPUTable = new ArrayList<String>(Arrays.asList("Device" , "CPU Avg", "Percent Changed"));
		List<String> headersValueMemory = new ArrayList<String>(Arrays.asList("Device", "Memory Avg", "Percent Changed"));
		
		reportLog("verify table header data");
		interfaceCapacityPage.verifyTopInterfaceBandwidthTableHeader(headersValue);		
		interfaceCapacityPage.verifyTopCPUTableHeader(headersValueOfCPUTable);		
		interfaceCapacityPage.verifyTopMemoryTableHeade(headersValueMemory);
    }
    
    @Test(dataProvider = "FilterInterfaceData", groups = "Interface Capacity", testName = "test_verifyInterfaceCapacityEportFunctionality", description = "Verify Interface filter functionality")
    public void test_verifyInterfaceFilterFunctionality(String site, String month, String timeWidnow ) throws InterruptedException{
    	
    	//Navigate to the stories page
    	reportLog("Navigate to the stories page");
        navBar.clickOnstoriesLink();
        
        //Click on Interface Capacity Link
        reportLog("Click on Interface Capacity Link");
        navBar.clickOnInLink(); 
        
        reportLog("apply filter data from left side drop down");
        interfaceCapacityPage.selectSite(site);
        interfaceCapacityPage.selectMonth(month);
        interfaceCapacityPage.selectTimeWindow(timeWidnow);
               
        //check if business hours not configured
        boolean status =  interfaceCapacityPage.isBusinessHoursNotConfigured();
        System.out.println(status);
        
        reportLog("verifying chart present");
		assertTrue(interfaceCapacityPage.verifyTopMemoryChart(), "Verify Top Memory Chart");
		assertTrue(interfaceCapacityPage.verifyTopCPUChart(), "Verify Top CPU Chart");
		assertTrue(interfaceCapacityPage.verifyTopInterfaceChart(), "Verify Top Interface Chart");        
        
		reportLog("verifying data present table");		
		interfaceCapacityPage.verifyTopInterfaceTableData();
		interfaceCapacityPage.verifyTopCPUTableData();
		interfaceCapacityPage.verifyTopMemoryTableData();		
    }
    
    @DataProvider(name = "FilterInterfaceData")
    public Object[][] createData1() {
            return new Object[][] {
              { "BOS", "July 2016", "Business Hours Only"},
              { "BOS", "June 2016", "Business Hours Only"},
              { "BOS", "April 2016", "Business Hours Only"},
             /* { "BOS", "March 2016", "Business Hours Only"},
              { "Chicago", "July 2016", "Business Hours Only"},
              { "Chicago", "June 2016", "Business Hours Only"},
              { "Chicago", "April 2016", "Business Hours Only"},
              { "Chicago", "March 2016", "Business Hours Only"},
              { "DataCenterCA", "July 2016", "Non-Business Hours Only"},
              { "DataCenterCA", "June 2016", "Non-Business Hours Only"},
              { "DataCenterCA", "April 2016", "Non-Business Hours Only"},*/
                       
            };
    }
}
