package com.liveaction.selenium.testCase;

import com.google.inject.Inject;
import com.google.inject.name.Named;
import com.liveaction.selenium.framework.BaseTest;
import com.liveaction.selenium.framework.MainBase;
import com.liveaction.selenium.pageObject.LoginPage;
import com.liveaction.selenium.pageObject.NavBarPageObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.annotations.Test;
import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertTrue;

public class LoginTest extends MainBase {
    private static final Logger logger = LoggerFactory.getLogger(LoginTest.class);

    @Inject @Named("login.invalid.username")
    private String invalidUsername;

    @Inject @Named("login.invalid.password")
    private String invalidPassword;

    @Inject @Named("label.invalid.login")
    private String invalidLoginText;

    @Inject
    private LoginPage loginPage;

    @Inject
    private NavBarPageObject navBar;

    @Test(description = "author:rhanson")
    public void validLoginLogoutTest() throws InterruptedException {
    	try{
	        logger.info("Attempting login with valid credentials");
	        loginPage.login();
	        assertTrue(navBar.isLogoutButtonPresent());
	        navBar.logout();
	        assertTrue(loginPage.isloginWithLiveActionFieldPresent());
    	}
    	catch(Exception ex){
    		captureScreenshot("validLoginLogoutTest");
    		throw ex;    		
    	}    	
    	catch(Error ex){
    		captureScreenshot("validLoginLogoutTest");
    		throw ex;    		
    	}
    }

    @Test(description = "author:rhanson")
    public void invalidLoginTest() throws InterruptedException{
    	try{
	        logger.info("Attempting login with invalid credentials: {}, {}", invalidUsername, invalidPassword);
	        loginPage.navigateToLoginPage();
	        loginPage.clickLoginWithLiveAction();
	        loginPage.setLoginDetails(invalidUsername, invalidPassword);
	        loginPage.clickLogin();
	        assertEquals(loginPage.getInvalidLoginText(), invalidLoginText);
    	}
    	catch(Exception ex){
    		captureScreenshot("invalidLoginTest");
    		throw ex;    		
    	}    	
    	catch(Error ex){
    		captureScreenshot("invalidLoginTest");
    		throw ex;    		
    	}
    }
}
