package com.liveaction.selenium.pageObject.settings;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

/**
 * @author hanson
 */
public class ConfigureApiPage extends SettingsPage {

    @FindBy(css="form[name='agentKeySetup'")
    private WebElement apiKeyForm;

    public boolean isApiKeyFormPresent() {
        return isPresentWithWait(apiKeyForm);
    }

}
