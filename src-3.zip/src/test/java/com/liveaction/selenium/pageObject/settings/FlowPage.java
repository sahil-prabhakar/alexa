package com.liveaction.selenium.pageObject.settings;

public class FlowPage extends SettingsPage  {
	
	

}
