package com.liveaction.selenium.pageObject;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.liveaction.selenium.framework.BasePageObject;

public class InventoryDetailsPage extends BasePageObject{

	@FindBy(xpath = "//div[@id='details']//span[1]")
	private WebElement deviceLbl;
	
	@FindBy(xpath = "//div[@id='details']//span[2]")
	private WebElement interfaceLbl;
	
	@FindBy(xpath = "//div[@id='details']//span[2]")
	private WebElement interfaceDetailsLnks;
	
	@FindBy(xpath = "//div[@id='sectioninterface_bandwidth']//div[contains(@class,'header-title')]")
	private WebElement interfaceBandwidthLbl;
	
	@FindBy(xpath="//div[@id='sectioninterface_bandwidth']//label[@ng-show='startTime']")
	private WebElement interfaceBandwidthStartTimeLbl;
	
	@FindBy(xpath="//div[@id='sectioninterface_bandwidth']//label[@ng-show='endTime']")
	private WebElement interfaceBandwidthEndTimeLbl;
	
	@FindBy(xpath="//div[@id='sectioninterface_bandwidth']//span[contains(@class,'start-time-value')]")
	private WebElement interfaceBandwidthStartTimeVal;
	
	@FindBy(xpath="//div[@id='sectioninterface_bandwidth']//span[contains(@class,'end-time-value')]")
	private WebElement interfaceBandwidthEndTimeVal;
	
	
	
	public String getDeviceLabel(){
		return deviceLbl.getText();
	}
	
	public String getInterfaceLabel(){
		return interfaceLbl.getText();
	}
	
	public void moveToInterfaceDetailsSection(String linkName){
		String linkLocator = "//a[contains(text(),'" + linkName + "')]";
		clickAndWait(interfaceDetailsLnks.findElement(By.xpath(linkLocator)));
	}
	
	public boolean verifyInterfaceBandWidthHeader(){
		return interfaceBandwidthLbl.isDisplayed();
	}
	
	public boolean verifyInterfaceBandWidthStartTimeLbl(){
		return interfaceBandwidthStartTimeLbl.isDisplayed();
	}
	
	public boolean verifyInterfaceBandWidthEndTimeLbl(){
		return interfaceBandwidthEndTimeLbl.isDisplayed();
	}
		
	public boolean verifyInterfaceBandWidthStartTimeValue(){
		return true;//interfaceBandwidthStartTimeVal.getText().contains(Utils.getCurrentTime());
	}
	
	public boolean verifyInterfaceBandWidthEndTimeValue(){
		return true;//interfaceBandwidthEndTimeVal.getText().contains(Utils.getCurrentTime());
	}
}
