package com.liveaction.selenium.pageObject;

import com.liveaction.selenium.framework.BasePageObject;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class SiteManagement extends BasePageObject {
	@FindBy(css=".breadcrumbs.pull-left>li:nth-child(2)")
	private WebElement siteManagement;
    
	
	public boolean isTitleText(String title){
		
			String value = siteManagement.getText();
			if(value.contains(title))
				return true;
		
			else 
				return false;
	}

}
