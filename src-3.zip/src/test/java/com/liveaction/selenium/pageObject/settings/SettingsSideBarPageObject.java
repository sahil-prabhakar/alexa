package com.liveaction.selenium.pageObject.settings;

import com.liveaction.selenium.framework.BasePageObject;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

/**
 * @author hanson
 */
public class SettingsSideBarPageObject extends BasePageObject {

	@FindBy(css = "a[href='/settings/tests']")
	private WebElement configureTestsLink;
	@FindBy(css = "a[href='/settings/agents']")
	private WebElement configureAgentsLink;
	@FindBy(css = "a[href='/settings/threshold-templates']")
	private WebElement configureThresholdsLink;
	@FindBy(css = "a[href='/settings/usermanagement']")
	private WebElement userManagementLink;
	@FindBy(css = "a[href='/settings/password']")
	private WebElement changePasswordLink;
	@FindBy(css = "a[href='/settings/api']")
	private WebElement configureApiLink;
	@FindBy(css = "a[href='/settings/database']")
	private WebElement databaseLink;
	@FindBy(css = "a[href='/settings/about']")
	private WebElement aboutLink;

	public void clickConfigureTests() {
		configureTestsLink.click();
	}

	public void clickConfigureAgents() {
		configureAgentsLink.click();
	}

	public void clickConfigureThresholds() {
		configureThresholdsLink.click();
	}

	public void clickUserManagement() {
		userManagementLink.click();
	}

	public void clickChangePassword() {
		changePasswordLink.click();
	}

	public void clickConfigureApi() {
		configureApiLink.click();
	}

	public void clickDatabase() {
		databaseLink.click();
	}

	public void clickAbout() {
		aboutLink.click();
	}
}
