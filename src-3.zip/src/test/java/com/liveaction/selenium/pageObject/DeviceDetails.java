package com.liveaction.selenium.pageObject;

import com.liveaction.selenium.framework.BasePageObject;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.liveaction.selenium.framework.BasePageObject;


public class DeviceDetails extends BasePageObject{

}
