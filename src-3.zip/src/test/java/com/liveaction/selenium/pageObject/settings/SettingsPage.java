package com.liveaction.selenium.pageObject.settings;

import com.liveaction.selenium.framework.BasePageObject;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

/**
 * @author hanson
 */
public class SettingsPage extends BasePageObject {

    @FindBy(css=".setup-step-title")
    private WebElement settingTitle;

    public String getSettingTitle(){
        return settingTitle.getText();
    }

}
