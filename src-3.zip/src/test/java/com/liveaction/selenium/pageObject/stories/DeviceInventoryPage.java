package com.liveaction.selenium.pageObject.stories;

import static org.testng.Assert.assertTrue;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.testng.Assert;

import com.liveaction.selenium.framework.BasePageObject;
import com.liveaction.selenium.framework.Utils;

public class DeviceInventoryPage extends BasePageObject {

	@FindBy(css = ".main-panel-title.ng-binding")
	private WebElement heaader;
	
	@FindBy(css = ".selectize-input.items")
	private WebElement devicesSelect;
	
	@FindBy(css = ".selectize-dropdown-content")
	private WebElement dropdpwnValue;
	
	@FindBy(xpath = "//nav[@id='myScrollspy']//a[text()='Devices']")
	private WebElement  devicesSideLink;
	
	@FindBy(xpath = "//nav[@id='myScrollspy']//a[text()='Interfaces']")
	private WebElement  InterfacesSideLink;
	
	@FindBy(css = ".header-title.ng-binding")
	private List<WebElement> headerTitle;
	
	@FindBy(xpath = "//div[@id='section13']/following-sibling::div//tr[contains(@class, 'title-list ng-scope')]/th")
	private List<WebElement> deviceTableHeader;
	
	@FindBy(xpath = "//div[@id='section13']/following-sibling::div//div//tbody/tr")
	private List<WebElement> deviceTableData;
	
	@FindBy(xpath = "//div[@id='section14']/following-sibling::div//tr[contains(@class, 'title-list ng-scope')]/th")
	private List<WebElement> interfaceTableHeader;
	
	@FindBy(xpath = "//div[@id='section14']/following-sibling::div//tbody/tr")
	private List<WebElement> interfaceTableData;
	
	@FindBy(xpath = "//div[@id='main-workflow-panel']/div/div[3]//*[@id='basic-addon2']")
	private WebElement intefaceSearchInput;
	
	@FindBy(xpath = "//div[@id='main-workflow-panel']/div/div[2]//span[@class='start-time-value ng-binding']")
	private WebElement deviceStartTime;
	
	@FindBy(xpath = "//div[@id='main-workflow-panel']/div/div[2]//span[@class='end-time-value ng-binding']")
	private WebElement deviceEndTime;
	
	@FindBy(xpath = "//div[@id='main-workflow-panel']/div/div[3]//span[@class='start-time-value ng-binding']")
	private WebElement interfaceStartTime;
	
	@FindBy(xpath = "//div[@id='main-workflow-panel']/div/div[3]//span[@class='end-time-value ng-binding']")
	private WebElement interfaceEndTime;
	
	@FindBy(xpath="//div[@id='main-workflow-panel']/div/div[2]//span[@class='dropdown']")
	private WebElement deviceExportIcon;
	
	@FindBy(xpath="//div[@id='main-workflow-panel']/div/div[3]//span[@class='dropdown']")
	private WebElement interfaceExportIcon;
	
	@FindBy(xpath="//div[@id='main-workflow-panel']/div/div[2]//a[text()='Export to CSV']")
	private WebElement exportDeviceLink;
	
	@FindBy(xpath="//div[@id='main-workflow-panel']/div/div[3]//a[text()='Export to CSV']")
	private WebElement exportInterfaceLink;
	
	
	@FindBy(xpath=".//tbody[1]/tr[1]/td[1]")
	private WebElement deviceLink;
	
	
	@FindBy(xpath=".//tbody[2]/tr[1]/td[1]/a/span")
	private WebElement intefaceLink;
	
	
	
	public void exportDeviceData(){
		waitForElementPresent(deviceExportIcon, 20);
		clickAndWait(deviceExportIcon);
		clickAndWait(exportDeviceLink);
	}
	
	public void exportInterfaceData(){
		waitForElementPresent(interfaceExportIcon, 20);
		Actions actions= new Actions(driver);
		actions.moveToElement(interfaceExportIcon).click().perform();
		//clickAndWait(interfaceExportIcon);
		clickAndWait(exportInterfaceLink);
	}
	
	public String getHeader() throws InterruptedException {
		Thread.sleep(2000);
		String text = heaader.getText();
		return text;
	}
	
	public void selectDevice(String devices) throws InterruptedException{
		click(devicesSelect);
		Thread.sleep(2000);
		WebElement el = dropdpwnValue.findElement(By.xpath("//div[text()='"+devices+"']"));
		click(el);
	}
	
	public boolean isSelected(String expectedDevices){
		String device = devicesSelect.getText();
		if(device.contains(expectedDevices))
			return true;
		return false;
	}
	
	public void clickDevicesLink(){
		clickAndWait(devicesSideLink);
	}
	
	public void clickInterfacesSideLink(){
		clickAndWait(InterfacesSideLink);
	}
	
	public boolean isHeaderTitle(String title){
		boolean status =false;
		for(WebElement el: headerTitle){
			if(el.getText().contains(title))
				return true;		
			}
		return status;
	}
	
	public void verifyDevicesHeader(List<String> tableHeader){
		List<String>  deviceTableHeaderValue = new ArrayList<String>();
		for(WebElement el : deviceTableHeader ){
			deviceTableHeaderValue.add(el.getText());
		}
		
		for(String str: tableHeader){
			assertTrue(contains(deviceTableHeaderValue, str ));
		}
	}
	
	public boolean isDeviceTableContainsData(){
		if(deviceTableData.size() > 0)
			return true;
		return false;
	}
	
	public void verifyDeviceColumnContainsLink(){
		for(WebElement el : deviceTableData){
			String tagName = el.findElement(By.xpath("//td/*[@class='ng-isolate-scope']")).getTagName();
			Assert.assertEquals(tagName, "a");
		}
	}
	
	public void  verifyInterfaceNameContainsLink(){
		for(WebElement el : interfaceTableHeader){
			String tagName = el.findElement(By.xpath("//td/*[@class='ng-isolate-scope']")).getTagName();
			System.out.println(tagName);
			Assert.assertEquals(tagName, "a");
		}
		
		for(WebElement el : interfaceTableHeader){
			String tagName = el.findElement(By.xpath("//td[2]/*[@class='ng-isolate-scope']")).getTagName();
			System.out.println(tagName);
			Assert.assertEquals(tagName, "a");
		}
	}
	
	public boolean isInterfaceTableContainsData(){
		if(interfaceTableData.size() > 0)
			return true;
		return false;
	}
	
	
	public void verifyInterfaceHeader(List<String> tableHeader){
		List<String>  interfaceTableHeaderData = new ArrayList<String>();
		for(WebElement el : interfaceTableHeader ){
			interfaceTableHeaderData.add(el.getText());
			System.out.println(el.getText());
		}
		
		for(String str: tableHeader){
			System.out.println(str);
			assertTrue(contains(interfaceTableHeaderData, str.toLowerCase() ));
		}
	}
	
	public static <T> boolean contains(final List<String> array, final String v) {
	    for (final String e : array)
	        if (e.toLowerCase() == v || v != null && v.equals(e.toLowerCase()))
	            return true;
	    return false;
	}
	
	public static <T> boolean contains(final String[] array, final String v) {
	    for (final String e : array)
	        if (e.toLowerCase() == v || v != null && v.equals(e.toLowerCase()))
	            return true;
	    return false;
	}
	
	public void searchInterface(String value){
		waitForElement(intefaceSearchInput);
		inputText(intefaceSearchInput, value);
		waitForAjaxRequestsToComplete();
		for(WebElement el : interfaceTableHeader){
			String columnvalue = el.findElement(By.xpath("//td[2]/*[@class='ng-isolate-scope']")).getText();
			Assert.assertTrue(columnvalue.contains(value), "column value is not equal expected "+columnvalue+" but actual "+value);			
		}		
	}
	
	public void verifyDeviceTime() throws InterruptedException{
		waitForAjaxRequestsToComplete();
		Thread.sleep(3000);
		String deviceStartTimeVaue = deviceStartTime.getText();
		String endTime = Utils.getBackTime(1);
		Assert.assertTrue(deviceStartTimeVaue.contains(endTime), "Actual "+deviceStartTimeVaue + "  Expected "+endTime);
		
		String currentTime = Utils.getCurrentTime();
		String deviceEndTimeVaue = deviceEndTime.getText();
		System.out.println("Actual "+deviceEndTimeVaue + "  Expected "+currentTime);
		Assert.assertTrue(deviceEndTimeVaue.contains(currentTime), "Actual "+deviceEndTimeVaue + "  Expected "+currentTime);
		
	}
	
	public void verifyInterfaceTime(){
		waitForAjaxRequestsToComplete();
		String interfaceStartTimeVaue = interfaceStartTime.getText();
		String endTime = Utils.getBackTime(1);
		Assert.assertTrue(interfaceStartTimeVaue.contains(endTime));
		
		String interfaceEndTimeVaue = interfaceEndTime.getText();
		String currentTime = Utils.getCurrentTime();
		Assert.assertTrue(interfaceEndTimeVaue.contains(currentTime));
	}
	
	public void verifyCSVHeader(List<String> headerValue, String[] headers){		
		for(String str: headers){
			System.out.println(str);
			assertTrue(contains(headers, str.toLowerCase() ));
		}
		
	}
    
	
	public void  getNumberOfLinks(){
		List<WebElement> abc=  driver.findElement(By.className("scroll-body")).findElements(By.tagName("tr"));
		
		for (WebElement we: abc)
		{
			String DeviceName=we.findElement(By.tagName("td[1])")).getText();
			String DeviceSerial=we.findElement(By.tagName("td[2])")).getText();
			
			System.out.print(DeviceSerial);
			System.out.print(DeviceName);
		}
	    
		
		 
		 
		
	}
	public WebElement  getCellLink(int col, int row)
	{
		WebElement w =null;
		w= driver.findElement(By.xpath("//div[@id='main-workflow-panel']//div[@class='ng-scope'][2]//div[@class='table-container']/table/tbody/tr["+row+"]/td["+col+"]/a"));		
		return w;
		
		
		
	}

	public String getPageUrl() {
		// TODO Auto-generated method stub
		return driver.getCurrentUrl();
	}
	
	public int getCSVLinkCount()
	{
	  List <WebElement> abc = driver.findElements(By.id("//div[@id='search-menu']/la-csv-download-button/span/span"));
	  return abc.size();
	}
}
