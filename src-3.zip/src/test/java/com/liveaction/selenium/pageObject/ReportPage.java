package com.liveaction.selenium.pageObject;

import java.util.List;

import org.openqa.selenium.By;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import com.liveaction.selenium.framework.BasePageObject;

public class ReportPage extends BasePageObject {
   


    @FindBy(xpath="//div[@class='selected-value']")
    private WebElement reportDropDown;
    
    @FindBy(css=".highcharts-contextmenu")
    private WebElement contextmenu;
     
    
    @FindBy(css=".mtree.bubba")
    private WebElement reportOptionSection;

    @FindBy(css="div[label='Time Range']>div>div>div")
    private WebElement timeRangeDropDown;
    
    @FindBy(css="div[name='deviceSelector']>div>div>div")
    private WebElement deviceDropDown;
    
    @FindBy(xpath="//div[text()='All Devices']")
    private WebElement allChannelValue;
    
    @FindBy(css="button[class='btn btn-success ng-binding']")
    private WebElement executeButton;
    
    @FindBy(css=".chart-container")
    private WebElement chartContainer;
    
    public void clickReportDropDown(){
    	clickAndWait(reportDropDown);
    }
    
    public void clickTimeRangeDropDown(){
    	waitForElement(timeRangeDropDown);
    	click(timeRangeDropDown);
    }
    
    public void clickDeviceDropDown(){
    	waitForElement(deviceDropDown);
    	click(deviceDropDown);
    }
    
    public void clickExecuteButton(){
    	waitForElement(executeButton);
    	click(executeButton);
    	waitForChart();
    }
    
    public void waitForChart(){
    	waitForElement(chartContainer);
    }
    
    
    public void selectReport(String reportName){
    	String locator = "//a[contains(text(), '"+reportName+"')]";
    	waitForElement(locator);
    	reportOptionSection.findElement(By.xpath(locator)).click();;
    }
    
    public void selectReport(List<String> reportsName){
    	for(String name: reportsName){
    		selectReport(name);
    	}
    }
    
    public void selectTimeRange(String value){
    	String locator = "//div[@class='selectize-dropdown-content']/div[text()='"+value+"']";
    	waitForElement(locator);
    	click(driver.findElement(By.xpath(locator)));
    }
    
    public void selectDevice(){
    	clickDeviceDropDown();
    	click(allChannelValue);
    }
    
    public void clickContext()
    {
    	
    	click(contextmenu);
    }
    public void clickContextLink(String value)
    {
       String contextLocator=".//*[@id='highcharts-0']/div[2]/div/div[text()='"+value+"']";
       click(driver.findElement(By.xpath(contextLocator)));
    }
    }


