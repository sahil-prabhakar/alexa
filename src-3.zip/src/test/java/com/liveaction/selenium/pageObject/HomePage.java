package com.liveaction.selenium.pageObject;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;

import com.liveaction.selenium.framework.BasePageObject;
import com.liveaction.selenium.framework.Utils;

public class HomePage extends BasePageObject {

	@FindBy(xpath = "//*[@model='deviceStatusControllerModel']")
	private WebElement siteChart;

	@FindBy(xpath = "//*[@model='deviceStatusControllerModel']")
	private WebElement deviceChart;

	@FindBy(xpath = "//*[@model='nxApplicationWidgetModel']")
	private WebElement applicationChart;

	@FindBy(css = ".selectize-input.items.not-full.ng-valid.ng-pristine.has-options")
	private WebElement siteInput;

	@FindBy(css = ".selectize-dropdown-content")
	private WebElement dropdownList;
	
	@FindBy(css = ".end-time-value.ng-binding")
	private WebElement endTime;
	
	@FindBy(css = ".start-time-value.ng-binding")
	private WebElement startTime;

	@FindBy(xpath=".//*[@class='ng-scope']")
	private List<WebElement> dropdownlinks;

	@FindBy(css = ".clear")
	private WebElement clear;

	public boolean isSiteCharts() {
		return isPresentWithWait(deviceChart);
	}

	public boolean isApplicationCharts() {
		return isPresentWithWait(applicationChart);

	}
	
	@FindBy(xpath=".//*[@id='search-menu']/la-csv-download-button/span/span")
	private WebElement  devicesDwnldLnk;
	
	@FindBy(xpath=".//*[@id='search-menu']/la-csv-download-button/span/ul//a[text()='Export to CSV']")
	private WebElement  deviceExportToCSVLnk;

	public boolean isDeviceCharts() {
		return isPresentWithWait(deviceChart);
	}
   
	
	
	public void clear() {
		click(clear);
	}

	public void selectSiteFromDrop() {
		click(siteInput);
	}

	public boolean isSiteListInDropDown() {
		List<WebElement> totalRow = dropdownList.findElements(By.tagName("div"));
		if (totalRow.size() > 1)
			return true;
		else
			return false;
	}
	
	public boolean isHeaderTitle(String title ){
		boolean status =false;
		  for (WebElement el :dropdownlinks)
			if(el.getText().contains(title))
			{
				return true;		
			}
		return status;
	}
	
	
	public void verifyDeviceTime() throws InterruptedException{
		waitForAjaxRequestsToComplete();
		Thread.sleep(3000);
		String deviceStartTimeVaue = startTime.getText();
		String endTime = Utils.getBackTime(1);
		Assert.assertTrue(deviceStartTimeVaue.contains(endTime), "Actual "+deviceStartTimeVaue + "  Expected "+endTime);
		
		String currentTime = Utils.getCurrentTime();
		String deviceEndTimeVaue = endTime;
		System.out.println("Actual "+deviceEndTimeVaue + "  Expected "+currentTime);
		Assert.assertTrue(deviceEndTimeVaue.contains(currentTime), "Actual "+deviceEndTimeVaue + "  Expected "+currentTime);
		
	}
	
	public boolean selectSite(String siteName) {
		List<WebElement> totalRow = dropdownList.findElements(By.cssSelector((".filter-label.ng-binding")));
		for (WebElement el : totalRow) {
			String site = el.getText();
			if (site.contains(siteName)) {
				el.click();
				break;
			}
		}
		if (totalRow.size() > 1)
			return true;
		else
			return false;
	}
	public int timeSlectSize()
	{
		List<WebElement> labels =  driver.findElements(By.cssSelector(".time-select-menu"));
		int size=labels.size();
		return size ;
	}
	
	public String selectDefaultTimeFromDropDown()

	{
	
		WebElement element=driver.findElement(By.cssSelector(".selected-value.ng-binding.active"));
		Select se=new Select(element);
		WebElement firstOption = se.getFirstSelectedOption();
		return firstOption.getText();
		
		
	}
	
	public void devicesDownloadCSV(){
		devicesDwnldLnk.click();
		deviceExportToCSVLnk.click();
	}
	
	
	
}
