package com.liveaction.selenium.pageObject.settings;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

/**
 * @author hanson
 */
public class ChangePasswordPage extends SettingsPage {

    @FindBy(css="form")
    private WebElement changePasswordForm;

    public boolean isChangePasswordFormPresent() {
        return isPresentWithWait(changePasswordForm);
    }

}
