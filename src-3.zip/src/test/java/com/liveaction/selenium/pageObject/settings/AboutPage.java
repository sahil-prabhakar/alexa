package com.liveaction.selenium.pageObject.settings;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

/**
 * @author hanson
 */
public class AboutPage extends SettingsPage{

    @FindBy(css="body > div.ng-scope > div.app-body.dashboard.settings-page.ng-scope > div.settings-page-content > div > div > div > div > div > div.row--step-body-content.settings-about.ng-scope > div > button")
    private WebElement updateVirtualApplianceButton;

    public void clickVirtualApplianceButton(){
        updateVirtualApplianceButton.click();
    } 

}
