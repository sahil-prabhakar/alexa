package com.liveaction.selenium.pageObject.settings;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

/**
 * @author hanson
 */
public class ConfigureTestsPage extends SettingsPage{

    @FindBy(css="button[ng-click='addRow()']")
    private WebElement addTestButton;

    @FindBy(css=".form-title")
    private WebElement createNewTestTitle;

    public void clickAddTestButton() {
        addTestButton.click();
    }

    public boolean isCreateNewTestTitlePresent() {
        return isPresentWithWait(createNewTestTitle);
    }

}
