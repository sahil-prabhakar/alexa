package com.liveaction.selenium.pageObject.settings;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

/**
 * @author hanson
 */
public class DatabasePage extends SettingsPage{

    @FindBy(css="table")
    private WebElement usageTable;

    public boolean isUsageTablePresent(){
        return isPresentWithWait(usageTable);
    }

}
