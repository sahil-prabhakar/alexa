package com.liveaction.selenium.pageObject;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.testng.Assert;
import org.testng.Reporter;

import com.liveaction.selenium.framework.BasePageObject;

public class DeviceInventoryPage extends BasePageObject {
	
	@FindBy(xpath =".//*[@id='main-workflow-panel']/div/div[1]")
	private WebElement mainHeader;

	public String getMainHeader() {
		String text = mainHeader.getText();
		return text;

	}
	
	@FindBy(xpath = ".//*[@id='myScrollspy']/ul/li[1]/a")
	private WebElement intbandchange;
	
	@FindBy(xpath = ".//*[@id='myScrollspy']/ul/li[2]/a")
	private WebElement cpuUsageLink;
	
	@FindBy(xpath = ".//*[@id='myScrollspy']/ul/li[3]/a")
	private WebElement topMemUsageLink;

	@FindBy(xpath = ".//*[@id='sectiontop_interface_bw_changes']/div/div[1]/div[1]")
	private WebElement topInterfaceBandHeader;
	
	
	public String gettopHeader() {
		String text = topInterfaceBandHeader.getText();
		return text;

	}

	public String getCpuHeader() {
		String text = topInterfaceBandHeader.getText();
		return text;

	}
	
	
	@FindBy(xpath = ".//*[@id='section11']/div/div[1]/div[1]")
	private WebElement topCpuUsagehead;
	
	@FindBy(xpath = ".//*[@id='myScrollspy']/ul/li")
	private WebElement linkContainer;


	public String topCpuUsage() {
		String text = topCpuUsagehead.getText();
		return text;

	}

	
	@FindBy(xpath = ".//*[@id='section12']/div/div[1]/div[1]")
	private WebElement topMemUsageHead;

	public String getinterHeader() {
		String text = topMemUsageHead.getText();
		return text;

	}
	
	

	public void  clickInterBandLink() {
    clickAndWait(intbandchange);

	}
	
	
	

	public void  clickOnInterfaceCapacity() {
    clickAndWait(intbandchange);

	}
	
	
	public void  clickCpuUsageLink() {
    clickAndWait(cpuUsageLink);
		

	}
    
	
	public void clickTopMem() {
    clickAndWait(topMemUsageLink);

	}
	
	public int getLinksInContainer(By container, By element)
	{
		WebElement mainDiv = driver.findElement(container);
		List<WebElement> hrefs = mainDiv.findElements(element);
		return hrefs.size();
	}

	public List<WebElement> gatherSideLinks (By container1) throws Exception
	{
		//click on link1 verify the header and side panel
		
		List<WebElement> mainDiv = driver.findElements(container1);
		
		clickSideLinks(mainDiv);
		return mainDiv;
	
	}
	
	public int captureLinks()
	{
		List<WebElement> container_links = driver.findElements(By.xpath(".//*[@id='myScrollspy']/ul/li"));
		System.out.print("all_links_page"+container_links.size());
		int size=container_links.size();
		return size;
	}
	
   public void clickSideLinks(List<WebElement> mainDiv) throws Exception {
	System.out.println ("links size"+mainDiv.size());
	try{
	  for (WebElement myElement: mainDiv)
	  {
		  String link=myElement.getText();
		  System.out.println(link);
		  
		  
	  
	  if (link !=""){
          myElement.click();
          Thread.sleep(2000);
          System.out.println("first");
         }
	  }
   }
	   catch (Exception e)
	  {
		  System.out.println("Error"+e.getMessage());
	  }
	   
   }
   
   public void VerifyHeader(WebElement maindiv, String hello ) throws Exception {
   {
	   
	   maindiv.click();
	   String Comparison=hello;
	   Assert.assertEquals(this.getCpuHeader(),Comparison);
	   Reporter.log("Header is passed");
   }
   }
   
 
   
}
	
	



