
package com.liveaction.selenium.pageObject;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.testng.Assert;

import com.liveaction.selenium.framework.BasePageObject;

public class InterfaceCapacityPage extends BasePageObject {

	@FindBy(css = "#myScrollspy")
	private WebElement heaader;
	
	@FindBy(css = ".main-panel-title.ng-binding")
	private WebElement mainHeaaderTitle;
			
	@FindBy(css = ".header-title.ng-binding")
	private List<WebElement>  heaaderTitle;
	
	@FindBy(xpath="//div[@id='main-workflow-panel']/div/div[@class='ng-scope'][1]//div[@class='table-container']/table")
	private WebElement topInterBandWidthChangesTbl;
	
	@FindBy(xpath="//div[@id='main-workflow-panel']//div[@class='ng-scope'][3]//la-csv-download-button/span/span")
	private WebElement  topMemoryUsageChangesDwnldLnk;
	
	@FindBy(xpath="//div[@id='main-workflow-panel']//div[@class='ng-scope'][3]//a[text()='Export to CSV']")
	private WebElement  topMemoryUsageChangesExportToCSVLnk;
	
	
	
	
	public String getHeader() {
		String text = heaader.getText();
		return text;
	}
	
	public void clickLinks(String link ){
		WebElement el = heaader.findElement(By.xpath("//a[text()='"+link+"']"));
		clickAndWait(el);
	}

	public void isHeaderText(String text){
		String tetValue = mainHeaaderTitle.getText();
		Assert.assertTrue(tetValue.contains(text));
	}
	
	public boolean isTitleText(String title){
		for(WebElement element : heaaderTitle){
			String value = element.getText();
			if(value.contains(title))
				return true;
		}
		return false;
	}
	
	
	public void navigateToInterCapacitySection(String sectionName){
		String locator = "//a[(text()='" + sectionName + "')]";
		  clickAndWait(findElement(By.xpath(locator)));		
	}
	
	public WebElement getInterBandWidthChangesTblCell(final int row,final int col){
		WebElement webElement= null;
		String cellLocator = "//tbody/tr[" + row + "]/td[" + col + "]";
		webElement = topInterBandWidthChangesTbl.findElement(By.xpath(cellLocator));
		return webElement;
	}
	
	public void navigateToInterfaceDetailsPage(final int row,final int col){
		String linkLocator = "//tbody/tr[" + row + "]/td[" + col + "]/a";
		topInterBandWidthChangesTbl.findElement(By.xpath(linkLocator));
		clickAndWait(topInterBandWidthChangesTbl.findElement(By.xpath(linkLocator)));
	}
	
	public void downloadTopMemoryUsageChangesCSV(){
		topMemoryUsageChangesDwnldLnk.click();
		topMemoryUsageChangesExportToCSVLnk.click();
	}
	
}

