package com.liveaction.selenium.pageObject.settings;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

/**
 * @author hanson
 */
public class ConfigureAgentsPage extends SettingsPage {

    @FindBy(css=".search-row")
    private WebElement searchBar;

    public boolean isSearchBarPresent() {
        return isPresentWithWait(searchBar);
    }

}
