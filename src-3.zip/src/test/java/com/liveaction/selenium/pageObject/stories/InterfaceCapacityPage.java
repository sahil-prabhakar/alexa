
package com.liveaction.selenium.pageObject.stories;

import static com.liveaction.selenium.datamodel.Stories.TopCPUUsageChanges;
import static com.liveaction.selenium.datamodel.Stories.TopInterfaceBandwidthChanges;
import static com.liveaction.selenium.datamodel.Stories.TopMemoryUsageChanges;
import static org.testng.Assert.assertTrue;

import java.util.List;

import org.apache.commons.io.FilenameUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.testng.Assert;

import com.liveaction.selenium.framework.BasePageObject;
import com.liveaction.selenium.framework.Utils;

public class InterfaceCapacityPage extends BasePageObject {

	@FindBy(css = "#myScrollspy")
	private WebElement heaader;
	
	@FindBy(css = ".main-panel-title.ng-binding")
	private WebElement mainHeaaderTitle;
			
	@FindBy(css = ".header-title.ng-binding")
	private List<WebElement>  heaaderTitle;
	
	@FindBy(xpath = ".//*[@class='scroll-body']/tr")
	private List<WebElement> deviceTableData;
	
	@FindBy(xpath="//div[@id='main-workflow-panel']/div/div[2]//*[@class=' highcharts-background']")
	private WebElement topInterfaceChart;
	
	@FindBy(xpath="//div[@id='main-workflow-panel']/div/div[3]//*[@class=' highcharts-background']")
	private WebElement  topCPUChart;
	
	@FindBy(xpath="//div[@id='main-workflow-panel']/div/div[4]//*[@class=' highcharts-background']")
	private WebElement topMemoryChart;
	
	@FindBy(xpath="//div[@id='main-workflow-panel']/div/div[2]//div[@class='table-container']/table/tbody/tr")
	private  List<WebElement> topInterfaceTable;
	
	@FindBy(xpath="//div[@id='main-workflow-panel']/div/div[3]//div[@class='table-container']/table/tbody/tr")
	private  List<WebElement> topCPUTable;
	
	@FindBy(xpath="//div[@id='main-workflow-panel']/div/div[4]//div[@class='table-container']/table/tbody/tr")
	private List<WebElement> topMemoryTable;
	
	@FindBy(xpath="//div[@id='main-workflow-panel']/div/div[2]//*[@class='highcharts-button']")
	private  WebElement topInterfaceChartDownIcon;
	
	@FindBy(xpath="//div[@id='main-workflow-panel']/div/div[3]//*[@class='highcharts-button']")
	private  WebElement topCPUChartDownloadIcon;
	
	@FindBy(xpath="//div[@id='main-workflow-panel']/div/div[4]//*[@class='highcharts-button']")
	private WebElement topMemoryChartDownloadIcon;
	
	@FindBy(xpath="//div[@id='main-workflow-panel']/div/div[2]//span[@class='dropdown']")
	private  WebElement topInterfaceTableDownloadIcon;
	
	@FindBy(xpath="//div[@id='main-workflow-panel']/div/div[3]//span[@class='dropdown']")
	private  WebElement topCPUTableDownloadIcon;
	
	@FindBy(xpath="//div[@id='main-workflow-panel']/div/div[4]//span[@class='dropdown']")
	private WebElement topMemoryTableDownloadIcon;
	
	@FindBy(xpath="//div[@id='main-workflow-panel']/div/div[2]//*[text()='Export to PNG']")
	private  WebElement topInterfaceExportPngIcon;
	
	@FindBy(xpath="//div[@id='main-workflow-panel']/div/div[3]//*[text()='Export to PNG']")
	private  WebElement topCPUTableExportPngIcon;
	
	@FindBy(xpath="//div[@id='main-workflow-panel']/div/div[4]//*[text()='Export to PNG']")
	private WebElement topMemoryExportPngIcon;
	
	@FindBy(xpath="//div[@id='main-workflow-panel']/div/div[2]//div[@class='chart']//*[text()='Export to CSV']")
	private  WebElement topInterfaceChartExportExcelIcon;
	
	@FindBy(xpath="//div[@id='main-workflow-panel']/div/div[3]//div[@class='chart']//*[text()='Export to CSV']")
	private  WebElement topCPUChartExportExcelIcon;
	
	@FindBy(xpath="//div[@id='main-workflow-panel']/div/div[4]//div[@class='chart']//*[text()='Export to CSV']")
	private WebElement topMemoryChartExportExcelIcon;
	
	@FindBy(xpath="//div[@id='main-workflow-panel']/div/div[2]//div[@id='search-menu']//*[text()='Export to CSV']")
	private  WebElement topInterfaceTableExportExcelIcon;
	
	@FindBy(xpath="//div[@id='main-workflow-panel']/div/div[3]//div[@id='search-menu']//*[text()='Export to CSV']")
	private  WebElement topCPUTableExcelIcon;
	
	@FindBy(xpath="//div[@id='main-workflow-panel']/div/div[4]//div[@id='search-menu']//*[text()='Export to CSV']")
	private WebElement topMemoryTableExportExcelIcon;
	
	@FindBy(xpath="//h4[text()='Site']/following-sibling::div/div/div[contains(@class,'selectize-control')]")
	private WebElement sizeSelectionBox;
	
	@FindBy(xpath="//h4[text()='Month']/following-sibling::div/div/div[contains(@class,'selectize-control')]")
	private WebElement monthSelectionBox;
	
	@FindBy(xpath="//h4[text()='Time Window']/following-sibling::div/div/div[contains(@class,'selectize-control')]")
	private WebElement timeWindowSelectionBox;
	
	@FindBy(xpath="//div[@id='main-workflow-panel']/div/div[2]//tr[@class='title-list ng-scope']/th")
	private List<WebElement> topInterfaceTableHeader;
	
	@FindBy(xpath="//div[@id='main-workflow-panel']/div/div[3]//tr[@class='title-list ng-scope']/th")
	private List<WebElement> topCPUTableHeader;
	
	@FindBy(xpath="//div[@id='main-workflow-panel']/div/div[4]//tr[@class='title-list ng-scope']/th")
	private List<WebElement> topMemoryTableHeader;
	
	@FindBy(xpath="//button[@ng-click='ok()']")
	private WebElement OKButton;
	
	
	public void verifyTopInterfaceBandwidthTableHeader(List<String> headers){
		for(String header: headers) {
			boolean status = false;
			for(WebElement el : topInterfaceTableHeader ){				
				if(el.getText().toLowerCase().contains(header.toLowerCase())){
					status = true;
					break;
				}					
			}
			Assert.assertTrue(status, "header not prsent "+header);
		}
	}
	
	public void verifyTopCPUTableHeader(List<String> headers){
		for(String header: headers) {
			boolean status = false;
			for(WebElement el : topCPUTableHeader ){				
				if(el.getText().toLowerCase().contains(header.toLowerCase())){
					status = true;
					break;
				}					
			}
			Assert.assertTrue(status, "header not prsent "+header);
		}
	}
	
	public void verifyTopMemoryTableHeade(List<String> headers){
		for(String header: headers) {
			boolean status = false;
			for(WebElement el : topMemoryTableHeader ){				
				if(el.getText().toLowerCase().contains(header.toLowerCase())){
					status = true;
					break;
				}					
			}
			Assert.assertTrue(status, "header not prsent "+header);
		}
	}
	
	public void selectSite(String site){
		click(sizeSelectionBox);
		selectDropDown(site);
	}
	
	public boolean isBusinessHoursNotConfigured() throws InterruptedException
	{
		waitForAjaxRequestsToComplete();
		Thread.sleep(2000);
		boolean status =isElementPresent("//button[@ng-click='ok()']");
		if(status)
			click(OKButton);
		return status;
	}
	public void selectDropDown(String value){
		String locator = "//div[@class='selectize-dropdown-content']/div[text()='"+value+"']";
		waitForElement(locator);
		try{
			click(driver.findElement(By.xpath(locator)));
		}
		catch(org.openqa.selenium.StaleElementReferenceException ex)
		{
			click(driver.findElement(By.xpath(locator)));
		}
	}
	public void selectMonth(String month){
		click(monthSelectionBox);
		selectDropDown(month);
	}
	
	public void selectTimeWindow(String timeWindow){
		click(timeWindowSelectionBox);
		selectDropDown(timeWindow);
	}
	
	public void exportAndVerifyTableCSVData() throws InterruptedException{
		Utils.clearDownloadDirectory();
		clickLinks(TopInterfaceBandwidthChanges.toString());
		waitForElement(topInterfaceTableDownloadIcon);
		click(topInterfaceTableDownloadIcon);
		click(topInterfaceTableExportExcelIcon);
		Thread.sleep(7000);		
		assertTrue(FilenameUtils.isExtension(Utils.getLatestFile().getName(), "csv"));
		
		Utils.clearDownloadDirectory();
		clickLinks(TopCPUUsageChanges.toString());
		click(topCPUTableDownloadIcon);
		click(topCPUTableExcelIcon);
		Thread.sleep(7000);
		assertTrue(FilenameUtils.isExtension(Utils.getLatestFile().getName(), "csv"));
		
		Utils.clearDownloadDirectory();
		waitForElement(topMemoryChartDownloadIcon);
		clickLinks(TopMemoryUsageChanges.toString());
		click(topMemoryTableDownloadIcon);
		click(topMemoryTableExportExcelIcon);
		Thread.sleep(7000);
		assertTrue(FilenameUtils.isExtension(Utils.getLatestFile().getName(), "csv"));
	}	
	
	
	public void exportAndVerifyPngGraph() throws InterruptedException{
		Utils.clearDownloadDirectory();
		clickLinks(TopInterfaceBandwidthChanges.toString());
		waitForElement(topInterfaceChartDownIcon);
		click(topInterfaceChartDownIcon);
		click(topInterfaceExportPngIcon);
		Thread.sleep(5000);		
		assertTrue(FilenameUtils.isExtension(Utils.getLatestFile().getName(), "png"));
		
		Utils.clearDownloadDirectory();
		waitForElement(topCPUChartDownloadIcon);
		clickLinks(TopCPUUsageChanges.toString());
		click(topCPUChartDownloadIcon);
		click(topCPUTableExportPngIcon);
		Thread.sleep(5000);
		assertTrue(FilenameUtils.isExtension(Utils.getLatestFile().getName(), "png"));
		
		Utils.clearDownloadDirectory();
		waitForElement(topMemoryChartDownloadIcon);
		clickLinks(TopMemoryUsageChanges.toString());
		click(topMemoryChartDownloadIcon);
		click(topMemoryExportPngIcon);
		Thread.sleep(5000);
		assertTrue(FilenameUtils.isExtension(Utils.getLatestFile().getName(), "png"));
	}
	
	public void exportAndVerifyCSVData() throws InterruptedException{
		Utils.clearDownloadDirectory();
		clickLinks(TopInterfaceBandwidthChanges.toString());
		waitForElement(topInterfaceChartDownIcon);
		click(topInterfaceChartDownIcon);
		click(topInterfaceChartExportExcelIcon);
		Thread.sleep(7000);		
		assertTrue(FilenameUtils.isExtension(Utils.getLatestFile().getName(), "csv"));
		
		Utils.clearDownloadDirectory();
		waitForElement(topCPUChartDownloadIcon);
		clickLinks(TopCPUUsageChanges.toString());
		click(topCPUChartDownloadIcon);
		click(topCPUChartExportExcelIcon);
		Thread.sleep(7000);
		assertTrue(FilenameUtils.isExtension(Utils.getLatestFile().getName(), "csv"));
		
		Utils.clearDownloadDirectory();
		waitForElement(topMemoryChartDownloadIcon);
		clickLinks(TopMemoryUsageChanges.toString());
		click(topMemoryChartDownloadIcon);
		click(topMemoryChartExportExcelIcon);
		Thread.sleep(7000);
		assertTrue(FilenameUtils.isExtension(Utils.getLatestFile().getName(), "csv"));
	}
	
	public void verifyTopInterfaceTableData(){
		int size = topInterfaceTable.size();
		Assert.assertTrue(size > 0, "No data on Top Interface Table ");
	}	
	
	public void verifyTopCPUTableData(){
		int size = topCPUTable.size();
		Assert.assertTrue(size > 0, "No data on Top CPU Table ");
	}
	
	public void verifyTopMemoryTableData(){
		int size = topMemoryTable.size();
		Assert.assertTrue(size > 0, "No data on Top Memory Table ");
	}
	public boolean verifyTopMemoryChart(){
		//waitForElement(topMemoryChart);
		return topMemoryChart.isDisplayed();
	}
	
	
	public boolean verifyTopCPUChart(){
		//waitForElement(topCPUChart);
		return topCPUChart.isDisplayed();
	}
	
	public boolean verifyTopInterfaceChart(){
		//waitForElement(topInterfaceChart);
		return topInterfaceChart.isDisplayed();
	}
	
	public String getHeader() {
		String text = heaader.getText();
		return text;
	}
	
	public void clickLinks(String link ){
		WebElement el = heaader.findElement(By.xpath("//a[text()='"+link+"']"));
		clickAndWait(el);
	}

	public void isHeaderText(String text){
		String tetValue = mainHeaaderTitle.getText();
		Assert.assertTrue(tetValue.contains(text));
	}
	
	public boolean isTitleText(String title){
		for(WebElement element : heaaderTitle){
			String value = element.getText();
			if(value.contains(title))
				return true;
		}
		return false;
	}
	
	public boolean isDeviceTableContainsData(){
		if(deviceTableData.size() > 0)
			return true;
		return false;
	}	
	
}

