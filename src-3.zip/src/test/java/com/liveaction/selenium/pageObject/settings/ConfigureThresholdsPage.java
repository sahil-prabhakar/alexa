package com.liveaction.selenium.pageObject.settings;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

/**
 * @author hanson
 */
public class ConfigureThresholdsPage extends SettingsPage {

    @FindBy(css="button[ng-click='addRow()']")
    private WebElement createTemplateButton;

    @FindBy(css="form[name='configureThresholds']")
    private WebElement configureThresholdTemplateForm;

    public void clickCreateTemplateButton() {
        createTemplateButton.click();
    }

    public boolean isConfigureThresholdTemplateFormPresent(){
        return isPresentWithWait(configureThresholdTemplateForm);
    }

}
