package com.liveaction.selenium.pageObject;

import com.liveaction.selenium.framework.BasePageObject;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class NavBarPageObject extends BasePageObject {

	@FindBy(css = "ul[class='dropdown-menu'] > li > a[ng-click='logout()']")
	private WebElement logoutButton;

	@FindBy(css = ".icon-username")
	private WebElement usernameIcon;

	@FindBy(css = ".glyphicon-cog")
	private WebElement settingsButton;



	
	@FindBy(xpath = "	//a[contains(.,'Stories')]")
	private WebElement storiesButton;
	
	@FindBy(xpath = ".//*[@id='navbar-app']/ul[2]/li[4]/a/i")
	private WebElement iconDrop;

      	
	@FindBy(xpath = "//a[text()='Site Management']")
	private WebElement siteManagementLink;
	
	@FindBy(xpath = "//a[text()='LDAP Management']")
	private WebElement ldapManagementLink;
	
	
	@FindBy(xpath = ".//*[@id='navbar-app']/ul[2]/li[5]/ul/li[3]/a")
	private WebElement wmicManagementLink;
	
	@FindBy(xpath = ".//*[@id='navbar-app']/ul[2]/li[4]/ul/li[1]/a")
	private WebElement interCapacityLink;


	
	@FindBy(xpath = ".//*[@id='navbar-app']/ul[2]/li[4]/ul/li[2]/a")
	private WebElement deviceInvLink;
	
	@FindBy(xpath = ".//*[@id='myScrollspy']/ul/li[3]/a")
	private WebElement topMemoryUsage;
	
	@FindBy(xpath = "//div[@id='navbar-app']//a[.='Interface Capacity']")
	private WebElement inCapacityLink;

	@FindBy(xpath = "//div[@id='navbar-app']//a[.='Device Inventory']")
	private WebElement deviceInventoryLink;


	@FindBy(css = ".dropdown-toggle.ng-binding")
	private WebElement storiesLink;

	@FindBy(xpath = "//div[@id='navbar-app']//a[text()='Home']")
	private WebElement homeButton;

	
	@FindBy(xpath = ".//*[@id='navbar-app']/ul[2]/li[5]")
	private WebElement configureButton;


	@FindBy(xpath = "	//a[contains(.,'TOPOLOGY')]")
	private WebElement topologyButton;

	@FindBy(xpath = "//div[@id='navbar-app']//a[contains(.,'Reports')]")
	private WebElement reportsButton;

	public boolean isLogoutButtonPresent() {
		click(usernameIcon);
		return isPresentWithWait(logoutButton);
	}

	public void logout() {
		click(usernameIcon);
		clickPotentiallyStaleElement(logoutButton);
	}

	public void clickSettings() {
		clickPotentiallyStaleElement(settingsButton);
		waitFor(pageLoad());
	}

	public void clickOnHomePage() {
		click(homeButton);
		waitFor(pageLoad());
	}

	public void clickOnConfigure() {
		click(configureButton);
		waitFor(pageLoad());
	}

	public void clickOnTopology() {
		click(topologyButton);
		waitFor(pageLoad());
	}

	public void clickOnReports() {
		click(reportsButton);
		waitFor(pageLoad());
	}

	public void clickOnInLink() {
		click(inCapacityLink);
		waitFor(pageLoad());
	}

	public void clickOndeviceInventoryLink() {
		click(deviceInventoryLink);
		waitFor(pageLoad());
	}

	public void clickOnstoriesLink() {
		click(storiesLink);
		waitFor(pageLoad());
	}
	
	public void clickOnIcon() {
		click(iconDrop);
		waitFor(pageLoad());
	}
	
	public void clickOnInterfaceCapacity()
	{
		clickAndWait(inCapacityLink);
		waitFor(pageLoad());
	}
		public void clickOnSiteManagement()
	{
		clickAndWait(siteManagementLink);
		//waitFor(pageLoad());
		
	}

	public void clickOnLDAPManagement() {
		clickAndWait(ldapManagementLink);
		
	}
	public void clickOnWMICManagement() {
	
		clickAndWait(wmicManagementLink);
		
	}


}
