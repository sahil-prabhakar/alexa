package com.liveaction.selenium.framework;

import org.sikuli.script.FindFailed;
import org.sikuli.script.Screen;

public class SikuliSupport {
	
	private static int waitTime = 30;
	private static String imagePath = "src/test/resources/images";
	
	public void clickImage(String image) throws FindFailed, InterruptedException{
		Screen screen = new Screen();
		waitForImage(image);
		screen.click(image);
	}

	public static boolean isImagePresent(String image)
    {
        boolean status = false;
        Screen screen = new Screen();
        try {
            screen.find(imagePath + "/"+image);
            status = true;
        } catch (FindFailed e) {           
            e.printStackTrace();
        }
        return status;
    } 
	
	public static boolean isTextPresent(String text)
    {
        boolean status = false;
        Screen screen = new Screen();
        try {
            screen.findAll(text);
            status = true;
        } catch (FindFailed e) {           
            e.printStackTrace();
        }
        return status;
    }
	
	public static void waitForImage(String image) throws InterruptedException{
        for(int i=0; i<waitTime; i++){
            if(isImagePresent(image)){
                break;
            }
            else{
                Thread.sleep(1000);
            }
        }
    }

}
