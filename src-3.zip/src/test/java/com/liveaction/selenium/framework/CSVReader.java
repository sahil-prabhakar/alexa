package com.liveaction.selenium.framework;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class CSVReader {
	
	private static String csvFilePath = System.getProperty("user.dir") + "/src/test/resources/download";
	private static String cvsSplitBy = ",";
	
	public static String[] getHeader(String fileName) {
		BufferedReader br = null;
		String[] headerValue = null;				
		try {
			FileReader fl = new FileReader(csvFilePath + "/"+fileName+".csv");
			br = new BufferedReader(fl);			
			headerValue = br.readLine().split(cvsSplitBy);	
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			if (br != null) {
				try {
					br.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
		return headerValue;
	  }	
}
